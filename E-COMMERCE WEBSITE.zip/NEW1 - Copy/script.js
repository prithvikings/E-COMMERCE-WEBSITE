
var i=0;
var images=[];
var time= 3000;

images[0]= '1.jpg';
images[1]= '2.jpg';
images[2]= '3.jpg';
images[3]= '4.jpg';

function changeImg(){
    document.slide.src= images[i];

    if(i < images.length - 1){
        i++;
    } else {
        i=0;
    }
    setTimeout("changeImg()", time);
}

window.onload = changeImg;


// SLIDER:
const productContainers = [...document.querySelectorAll('.product-container')];

const nxtBtn = [...document.querySelectorAll('.nxt-btn')];
const preBtn = [...document.querySelectorAll('.pre-btn')];

productContainers.forEach((item, i) => {
    let containerDimensions = item.getBoundingClientRect();
    let containerWidth = containerDimensions.width;

    nxtBtn[i].addEventListener('click', () => {
        item.scrollLeft += containerWidth;
    })

    preBtn[i].addEventListener('click', () => {
        item.scrollLeft -= containerWidth;
    })
})